window.config = {
  baseUrl: '/logistics'
}
